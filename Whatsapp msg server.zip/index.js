const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const cron = require('node-cron');
const express = require('express');

// You can change this to your phone number (including country code) to receive status alerts
// For example: '1234567890@c.us'
const ADMIN_NUMBER = 'YOUR_NUMBER_HERE@c.us';

// Array of exact group names you want the bot to be able to message
const TARGET_GROUPS = ['Bot', 'Test Group 2'];

const app = express();
app.use(express.json());

// Initialize the client with LocalAuth for persistent sessions
// This creates a .wwebjs_auth folder to save session data
const client = new Client({
    authStrategy: new LocalAuth({
        clientId: 'bot-session' // Optional: use if running multiple sessions
    }),
    puppeteer: {
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
    }
});

let isReady = false;

// Generate QR code for authentication
client.on('qr', (qr) => {
    console.log('\n======================================================');
    console.log('Session expired or not found! Please scan the QR code:');
    console.log('======================================================\n');
    qrcode.generate(qr, { small: true });
});

// Session successfully authenticated
client.on('authenticated', () => {
    console.log('Authentication successful! Session is now persistent.');
});

// Session authentication failed
client.on('auth_failure', msg => {
    console.error('Authentication failed:', msg);
    isReady = false;
});

// Client is ready
client.on('ready', () => {
    console.log('WhatsApp Bot is ready and connected!');
    isReady = true;

    // Send a startup notification to the admin
    if (ADMIN_NUMBER !== 'YOUR_NUMBER_HERE@c.us') {
        client.sendMessage(ADMIN_NUMBER, '🤖 Bot successfully started and connected!');
    }
});

// Monitor session disconnection
client.on('disconnected', (reason) => {
    console.log('Bot was disconnected:', reason);
    isReady = false;

    // Attempting to notify if still somewhat connected, but usually impossible if fully disconnected.
    console.log('ACTION REQUIRED: Session was disconnected. You will need to re-scan the QR code upon restart.');
});


// ==========================================
// AUTO-NOTIFICATION & SESSION HEALTH CHECK
// ==========================================
// Since WhatsApp sessions don't conventionally "expire" unless unlinked from the phone,
// we set up a cron job to check if the bot is still responding and notify the admin.
// This runs every day at 12:00 PM (noon).
cron.schedule('0 12 * * *', async () => {
    if (isReady) {
        console.log('Running daily health check: Bot is active.');
        try {
            const state = await client.getState();
            if (state === 'CONNECTED') {
                if (ADMIN_NUMBER !== 'YOUR_NUMBER_HERE@c.us') {
                    client.sendMessage(ADMIN_NUMBER, `🟢 Daily Health Check: Bot is connected and active.\nTime: ${new Date().toLocaleString()}`);
                }
            } else {
                console.log('Bot state is not CONNECTED:', state);
            }
        } catch (error) {
            console.error('Error checking bot state:', error);
        }
    } else {
        console.log('Daily health check: Bot is OFFLINE or waiting for QR scan.');
    }
});


// ==========================================
// GROUP MESSAGING FUNCTIONS
// ==========================================

// Helper function to find a group ID by its name
async function getGroupIdByName(groupName) {
    try {
        const chats = await client.getChats();
        // Finding a chat that is a group and matches the specified name
        const targetGroup = chats.find(chat => chat.isGroup && chat.name === groupName);

        if (targetGroup) {
            return targetGroup.id._serialized;
        } else {
            return null;
        }
    } catch (error) {
        console.error('Error fetching chats:', error);
        return null;
    }
}

/**
 * Send a message to a specific group by name
 */
async function sendToGroup(groupName, message) {
    if (!isReady) {
        throw new Error('Bot is not ready. Please wait or scan the QR code.');
    }

    const groupId = await getGroupIdByName(groupName);

    if (groupId) {
        await client.sendMessage(groupId, message);
        console.log(`Message successfully sent to group: ${groupName}`);
        return { success: true, message: 'Sent' };
    } else {
        console.error(`Group "${groupName}" not found.`);
        return { success: false, error: 'Group not found' };
    }
}


// ==========================================
// API ENDPOINTS (Optional: to trigger messages externally)
// ==========================================

// Endpoint to send a message to a group
app.post('/api/send-group', async (req, res) => {
    const { groupName, message } = req.body;

    if (!groupName || !message) {
        return res.status(400).json({ error: 'Please provide both groupName and message.' });
    }

    try {
        const result = await sendToGroup(groupName, message);
        if (result.success) {
            res.status(200).json({ status: 'Success', message: 'Message sent to group.' });
        } else {
            res.status(404).json({ status: 'Failed', error: result.error });
        }
    } catch (error) {
        res.status(500).json({ status: 'Error', error: error.message });
    }
});

// Check bot status endpoint
app.get('/api/status', (req, res) => {
    res.json({
        online: isReady,
        timestamp: new Date().toISOString()
    });
});

// Start the Express server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`API Server is running on http://localhost:${PORT}`);
});

// Start the WhatsApp Client
client.initialize();
